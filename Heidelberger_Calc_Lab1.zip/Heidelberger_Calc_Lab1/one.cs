﻿using System.Windows.Forms;

namespace Heidelberger_Calc_Lab1
{
    internal class one : Form
    {
    }
}