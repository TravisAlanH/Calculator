﻿
namespace Heidelberger_Calc_Lab1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInputOutput = new System.Windows.Forms.TextBox();
            this.sqrt = new System.Windows.Forms.Button();
            this.xPowTwo = new System.Windows.Forms.Button();
            this.xPowY = new System.Windows.Forms.Button();
            this.oneDivX = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.delete = new System.Windows.Forms.Button();
            this.clearAll = new System.Windows.Forms.Button();
            this.clearEntry = new System.Windows.Forms.Button();
            this.multipy = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.equal = new System.Windows.Forms.Button();
            this.dec = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.posNeg = new System.Windows.Forms.Button();
            this.plus = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInputOutput
            // 
            this.txtInputOutput.Location = new System.Drawing.Point(13, 13);
            this.txtInputOutput.Name = "txtInputOutput";
            this.txtInputOutput.Size = new System.Drawing.Size(362, 39);
            this.txtInputOutput.TabIndex = 0;
            // 
            // sqrt
            // 
            this.sqrt.Location = new System.Drawing.Point(13, 58);
            this.sqrt.Name = "sqrt";
            this.sqrt.Size = new System.Drawing.Size(86, 68);
            this.sqrt.TabIndex = 1;
            this.sqrt.Text = "Sqrt";
            this.sqrt.UseVisualStyleBackColor = true;
            this.sqrt.Click += new System.EventHandler(this.sqrt_Click);
            // 
            // xPowTwo
            // 
            this.xPowTwo.Location = new System.Drawing.Point(105, 58);
            this.xPowTwo.Name = "xPowTwo";
            this.xPowTwo.Size = new System.Drawing.Size(86, 68);
            this.xPowTwo.TabIndex = 2;
            this.xPowTwo.Text = "x^2";
            this.xPowTwo.UseVisualStyleBackColor = true;
            this.xPowTwo.Click += new System.EventHandler(this.xPowTwo_Click);
            // 
            // xPowY
            // 
            this.xPowY.Location = new System.Drawing.Point(197, 58);
            this.xPowY.Name = "xPowY";
            this.xPowY.Size = new System.Drawing.Size(86, 68);
            this.xPowY.TabIndex = 3;
            this.xPowY.Text = "x^y";
            this.xPowY.UseVisualStyleBackColor = true;
            this.xPowY.Click += new System.EventHandler(this.xPowY_Click);
            // 
            // oneDivX
            // 
            this.oneDivX.Location = new System.Drawing.Point(289, 58);
            this.oneDivX.Name = "oneDivX";
            this.oneDivX.Size = new System.Drawing.Size(86, 68);
            this.oneDivX.TabIndex = 4;
            this.oneDivX.Text = "1/x";
            this.oneDivX.UseVisualStyleBackColor = true;
            this.oneDivX.Click += new System.EventHandler(this.oneDivX_Click);
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(289, 132);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(86, 68);
            this.divide.TabIndex = 8;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = true;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // delete
            // 
            this.delete.Location = new System.Drawing.Point(197, 132);
            this.delete.Name = "delete";
            this.delete.Size = new System.Drawing.Size(86, 68);
            this.delete.TabIndex = 7;
            this.delete.Text = "Del.";
            this.delete.UseVisualStyleBackColor = true;
            this.delete.Click += new System.EventHandler(this.delete_Click);
            // 
            // clearAll
            // 
            this.clearAll.Location = new System.Drawing.Point(105, 132);
            this.clearAll.Name = "clearAll";
            this.clearAll.Size = new System.Drawing.Size(86, 68);
            this.clearAll.TabIndex = 6;
            this.clearAll.Text = "C";
            this.clearAll.UseVisualStyleBackColor = true;
            this.clearAll.Click += new System.EventHandler(this.clearAll_Click);
            // 
            // clearEntry
            // 
            this.clearEntry.Location = new System.Drawing.Point(13, 132);
            this.clearEntry.Name = "clearEntry";
            this.clearEntry.Size = new System.Drawing.Size(86, 68);
            this.clearEntry.TabIndex = 5;
            this.clearEntry.Text = "CE";
            this.clearEntry.UseVisualStyleBackColor = true;
            this.clearEntry.Click += new System.EventHandler(this.clearEntry_Click);
            // 
            // multipy
            // 
            this.multipy.Location = new System.Drawing.Point(289, 206);
            this.multipy.Name = "multipy";
            this.multipy.Size = new System.Drawing.Size(86, 68);
            this.multipy.TabIndex = 12;
            this.multipy.Text = "X";
            this.multipy.UseVisualStyleBackColor = true;
            this.multipy.Click += new System.EventHandler(this.multipy_Click);
            // 
            // nine
            // 
            this.nine.Location = new System.Drawing.Point(197, 206);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(86, 68);
            this.nine.TabIndex = 11;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = true;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // eight
            // 
            this.eight.Location = new System.Drawing.Point(105, 206);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(86, 68);
            this.eight.TabIndex = 10;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = true;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // seven
            // 
            this.seven.Location = new System.Drawing.Point(13, 206);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(86, 68);
            this.seven.TabIndex = 9;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = true;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // equal
            // 
            this.equal.Location = new System.Drawing.Point(289, 429);
            this.equal.Name = "equal";
            this.equal.Size = new System.Drawing.Size(86, 68);
            this.equal.TabIndex = 24;
            this.equal.Text = "=";
            this.equal.UseVisualStyleBackColor = true;
            this.equal.Click += new System.EventHandler(this.equal_Click);
            // 
            // dec
            // 
            this.dec.Location = new System.Drawing.Point(197, 429);
            this.dec.Name = "dec";
            this.dec.Size = new System.Drawing.Size(86, 68);
            this.dec.TabIndex = 23;
            this.dec.Text = ".";
            this.dec.UseVisualStyleBackColor = true;
            this.dec.Click += new System.EventHandler(this.dec_Click);
            // 
            // zero
            // 
            this.zero.Location = new System.Drawing.Point(105, 429);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(86, 68);
            this.zero.TabIndex = 22;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = true;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // posNeg
            // 
            this.posNeg.Location = new System.Drawing.Point(13, 429);
            this.posNeg.Name = "posNeg";
            this.posNeg.Size = new System.Drawing.Size(86, 68);
            this.posNeg.TabIndex = 21;
            this.posNeg.Text = "+/-";
            this.posNeg.UseVisualStyleBackColor = true;
            this.posNeg.Click += new System.EventHandler(this.posNeg_Click);
            // 
            // plus
            // 
            this.plus.Location = new System.Drawing.Point(289, 355);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(86, 68);
            this.plus.TabIndex = 20;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = true;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // three
            // 
            this.three.Location = new System.Drawing.Point(197, 355);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(86, 68);
            this.three.TabIndex = 19;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = true;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // two
            // 
            this.two.Location = new System.Drawing.Point(105, 355);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(86, 68);
            this.two.TabIndex = 18;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = true;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.Location = new System.Drawing.Point(13, 355);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(86, 68);
            this.one.TabIndex = 17;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = true;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // minus
            // 
            this.minus.Location = new System.Drawing.Point(289, 281);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(86, 68);
            this.minus.TabIndex = 16;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = true;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // six
            // 
            this.six.Location = new System.Drawing.Point(197, 281);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(86, 68);
            this.six.TabIndex = 15;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = true;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // five
            // 
            this.five.Location = new System.Drawing.Point(105, 281);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(86, 68);
            this.five.TabIndex = 14;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = true;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // four
            // 
            this.four.Location = new System.Drawing.Point(13, 281);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(86, 68);
            this.four.TabIndex = 13;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = true;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(392, 514);
            this.Controls.Add(this.equal);
            this.Controls.Add(this.dec);
            this.Controls.Add(this.zero);
            this.Controls.Add(this.posNeg);
            this.Controls.Add(this.plus);
            this.Controls.Add(this.three);
            this.Controls.Add(this.two);
            this.Controls.Add(this.one);
            this.Controls.Add(this.minus);
            this.Controls.Add(this.six);
            this.Controls.Add(this.five);
            this.Controls.Add(this.four);
            this.Controls.Add(this.multipy);
            this.Controls.Add(this.nine);
            this.Controls.Add(this.eight);
            this.Controls.Add(this.seven);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.delete);
            this.Controls.Add(this.clearAll);
            this.Controls.Add(this.clearEntry);
            this.Controls.Add(this.oneDivX);
            this.Controls.Add(this.xPowY);
            this.Controls.Add(this.xPowTwo);
            this.Controls.Add(this.sqrt);
            this.Controls.Add(this.txtInputOutput);
            this.KeyPreview = true;
            this.Name = "Form1";
            this.Text = "Calc Yo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInputOutput;
        private System.Windows.Forms.Button sqrt;
        private System.Windows.Forms.Button xPowTwo;
        private System.Windows.Forms.Button xPowY;
        private System.Windows.Forms.Button oneDivX;
        private System.Windows.Forms.Button divide;
        private System.Windows.Forms.Button delete;
        private System.Windows.Forms.Button clearAll;
        private System.Windows.Forms.Button clearEntry;
        private System.Windows.Forms.Button multipy;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button equal;
        private System.Windows.Forms.Button dec;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button posNeg;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button four;
    }
}

